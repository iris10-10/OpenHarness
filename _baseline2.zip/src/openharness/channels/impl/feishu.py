"""Feishu/Lark channel implementation using lark-oapi SDK with WebSocket long connection."""

import asyncio
import json
import os
import re
import threading
from collections import OrderedDict
from dataclasses import dataclass
from typing import Any


from openharness.channels.bus.events import OutboundMessage
from openharness.channels.bus.queue import MessageBus
from openharness.channels.impl.base import BaseChannel
from openharness.channels.impl.base import resolve_channel_media_dir
from openharness.config.schema import FeishuConfig
from openharness.utils.helpers import safe_filename

import importlib.util
import logging

logger = logging.getLogger(__name__)

FEISHU_AVAILABLE = importlib.util.find_spec("lark_oapi") is not None

# Message type display mapping
MSG_TYPE_MAP = {
    "image": "[image]",
    "audio": "[audio]",
    "file": "[file]",
    "sticker": "[sticker]",
}


@dataclass(frozen=True)
class _FeishuSenderInfo:
    open_id: str
    display_name: str


def _clean_mention_value(value: Any) -> str:
    if value is None:
        return ""
    return str(value).strip()


def _normalize_mention_name(value: str) -> str:
    return value.strip().lstrip("@").strip().lower()


def _configured_bot_names(config: FeishuConfig) -> set[str]:
    raw_names = getattr(config, "bot_names", []) or []
    if isinstance(raw_names, str):
        items = [item.strip() for item in raw_names.split(",")]
    else:
        items = [str(item).strip() for item in raw_names]
    names = {_normalize_mention_name(item) for item in items if item.strip()}
    return names or {"ohmo"}


def _mention_value(raw: Any, key: str) -> Any:
    if isinstance(raw, dict):
        return raw.get(key)
    return getattr(raw, key, None)


def _mention_id_value(raw_id: Any, key: str) -> Any:
    if isinstance(raw_id, dict):
        return raw_id.get(key)
    return getattr(raw_id, key, None)


def _extract_feishu_mentions(
    content_json: dict,
    raw_mentions: list[Any] | tuple[Any, ...] | None = None,
) -> list[dict[str, str]]:
    """Return normalized mention metadata from Feishu text/post payloads."""
    mentions: list[dict[str, str]] = []
    seen: set[tuple[str, str, str, str, str]] = set()

    def add(raw: Any) -> None:
        mention_id = _mention_value(raw, "id") or {}
        record = {
            "key": _clean_mention_value(_mention_value(raw, "key")),
            "name": _clean_mention_value(_mention_value(raw, "name") or _mention_value(raw, "user_name")),
            "open_id": _clean_mention_value(
                _mention_value(raw, "open_id") or _mention_id_value(mention_id, "open_id")
            ),
            "user_id": _clean_mention_value(
                _mention_value(raw, "user_id") or _mention_id_value(mention_id, "user_id")
            ),
            "union_id": _clean_mention_value(
                _mention_value(raw, "union_id") or _mention_id_value(mention_id, "union_id")
            ),
        }
        key = (record["key"], record["name"], record["open_id"], record["user_id"], record["union_id"])
        if any(record.values()) and key not in seen:
            seen.add(key)
            mentions.append(record)

    if raw_mentions:
        for item in raw_mentions:
            add(item)

    raw_mentions = content_json.get("mentions")
    if isinstance(raw_mentions, list):
        for item in raw_mentions:
            if isinstance(item, dict):
                add(item)

    def walk(value: Any) -> None:
        if isinstance(value, dict):
            if value.get("tag") == "at":
                add(value)
            for child in value.values():
                walk(child)
        elif isinstance(value, list):
            for child in value:
                walk(child)

    walk(content_json)
    return mentions


def _feishu_mentions_bot(
    content_json: dict,
    text: str,
    config: FeishuConfig,
    *,
    mentions: list[dict[str, str]] | None = None,
) -> bool:
    """Best-effort bot mention detection for Feishu group messages."""
    bot_open_id = str(getattr(config, "bot_open_id", "") or "").strip()
    bot_names = _configured_bot_names(config)
    for mention in mentions if mentions is not None else _extract_feishu_mentions(content_json):
        ids = {mention.get("open_id", ""), mention.get("user_id", ""), mention.get("union_id", "")}
        if bot_open_id and bot_open_id in ids:
            return True
        name = _normalize_mention_name(mention.get("name", ""))
        if name and any(name == candidate or candidate in name for candidate in bot_names):
            return True

    normalized_text = text.strip().lower()
    for name in bot_names:
        if re.search(rf"(^|\s)@{re.escape(name)}(?=$|\s|[:：,，])", normalized_text):
            return True
    return False


def _normalize_feishu_group_policy(value: str | None) -> str:
    normalized = str(value or "").strip().lower().replace("-", "_")
    aliases = {
        "all": "open",
        "always": "open",
        "always_reply": "open",
        "managed_mention": "managed_or_mention",
        "managed_or_at": "managed_or_mention",
        "at": "mention",
        "mentions": "mention",
    }
    normalized = aliases.get(normalized, normalized)
    if normalized in {"open", "mention", "managed", "managed_or_mention"}:
        return normalized
    return "managed_or_mention"


def _is_ohmo_managed_feishu_group(chat_id: str) -> bool:
    workspace = os.environ.get("OHMO_WORKSPACE")
    if not workspace:
        return False
    try:
        from ohmo.group_registry import load_managed_group_record

        return load_managed_group_record(
            workspace=workspace,
            channel="feishu",
            chat_id=chat_id,
        ) is not None
    except Exception:
        logger.exception("Failed to load ohmo managed Feishu group metadata chat_id=%s", chat_id)
        return False


def _should_process_feishu_group_message(
    *,
    chat_type: str,
    chat_id: str,
    mentions_bot: bool,
    config: FeishuConfig,
) -> bool:
    if str(chat_type or "").strip().lower() != "group":
        return True
    policy = _normalize_feishu_group_policy(getattr(config, "group_policy", "managed_or_mention"))
    if policy == "open":
        return True
    if policy == "mention":
        return mentions_bot
    if policy == "managed":
        return _is_ohmo_managed_feishu_group(chat_id)
    if policy == "managed_or_mention":
        return mentions_bot or _is_ohmo_managed_feishu_group(chat_id)
    return mentions_bot


class FeishuApiError(RuntimeError):
    """Raised when Feishu returns an unsuccessful API response."""


def _extract_share_card_content(content_json: dict, msg_type: str) -> str:
    """Extract text representation from share cards and interactive messages."""
    parts = []

    if msg_type == "share_chat":
        parts.append(f"[shared chat: {content_json.get('chat_id', '')}]")
    elif msg_type == "share_user":
        parts.append(f"[shared user: {content_json.get('user_id', '')}]")
    elif msg_type == "interactive":
        parts.extend(_extract_interactive_content(content_json))
    elif msg_type == "share_calendar_event":
        parts.append(f"[shared calendar event: {content_json.get('event_key', '')}]")
    elif msg_type == "system":
        parts.append("[system message]")
    elif msg_type == "merge_forward":
        parts.append("[merged forward messages]")

    return "\n".join(parts) if parts else f"[{msg_type}]"


def _extract_interactive_content(content: dict) -> list[str]:
    """Recursively extract text and links from interactive card content."""
    parts = []

    if isinstance(content, str):
        try:
            content = json.loads(content)
        except (json.JSONDecodeError, TypeError):
            return [content] if content.strip() else []

    if not isinstance(content, dict):
        return parts

    if "title" in content:
        title = content["title"]
        if isinstance(title, dict):
            title_content = title.get("content", "") or title.get("text", "")
            if title_content:
                parts.append(f"title: {title_content}")
        elif isinstance(title, str):
            parts.append(f"title: {title}")

    for elements in content.get("elements", []) if isinstance(content.get("elements"), list) else []:
        for element in elements:
            parts.extend(_extract_element_content(element))

    card = content.get("card", {})
    if card:
        parts.extend(_extract_interactive_content(card))

    header = content.get("header", {})
    if header:
        header_title = header.get("title", {})
        if isinstance(header_title, dict):
            header_text = header_title.get("content", "") or header_title.get("text", "")
            if header_text:
                parts.append(f"title: {header_text}")

    return parts


def _extract_element_content(element: dict) -> list[str]:
    """Extract content from a single card element."""
    parts = []

    if not isinstance(element, dict):
        return parts

    tag = element.get("tag", "")

    if tag in ("markdown", "lark_md"):
        content = element.get("content", "")
        if content:
            parts.append(content)

    elif tag == "div":
        text = element.get("text", {})
        if isinstance(text, dict):
            text_content = text.get("content", "") or text.get("text", "")
            if text_content:
                parts.append(text_content)
        elif isinstance(text, str):
            parts.append(text)
        for field in element.get("fields", []):
            if isinstance(field, dict):
                field_text = field.get("text", {})
                if isinstance(field_text, dict):
                    c = field_text.get("content", "")
                    if c:
                        parts.append(c)

    elif tag == "a":
        href = element.get("href", "")
        text = element.get("text", "")
        if href:
            parts.append(f"link: {href}")
        if text:
            parts.append(text)

    elif tag == "button":
        text = element.get("text", {})
        if isinstance(text, dict):
            c = text.get("content", "")
            if c:
                parts.append(c)
        url = element.get("url", "") or element.get("multi_url", {}).get("url", "")
        if url:
            parts.append(f"link: {url}")

    elif tag == "img":
        alt = element.get("alt", {})
        parts.append(alt.get("content", "[image]") if isinstance(alt, dict) else "[image]")

    elif tag == "note":
        for ne in element.get("elements", []):
            parts.extend(_extract_element_content(ne))

    elif tag == "column_set":
        for col in element.get("columns", []):
            for ce in col.get("elements", []):
                parts.extend(_extract_element_content(ce))

    elif tag == "plain_text":
        content = element.get("content", "")
        if content:
            parts.append(content)

    else:
        for ne in element.get("elements", []):
            parts.extend(_extract_element_content(ne))

    return parts


def _extract_post_content(content_json: dict) -> tuple[str, list[str]]:
    """Extract text and image keys from Feishu post (rich text) message.

    Handles three payload shapes:
    - Direct:    {"title": "...", "content": [[...]]}
    - Localized: {"zh_cn": {"title": "...", "content": [...]}}
    - Wrapped:   {"post": {"zh_cn": {"title": "...", "content": [...]}}}
    """

    def _parse_block(block: dict) -> tuple[str | None, list[str]]:
        if not isinstance(block, dict) or not isinstance(block.get("content"), list):
            return None, []
        texts, images = [], []
        if title := block.get("title"):
            texts.append(title)
        for row in block["content"]:
            if not isinstance(row, list):
                continue
            for el in row:
                if not isinstance(el, dict):
                    continue
                tag = el.get("tag")
                if tag in ("text", "a"):
                    texts.append(el.get("text", ""))
                elif tag == "at":
                    texts.append(f"@{el.get('user_name', 'user')}")
                elif tag == "img" and (key := el.get("image_key")):
                    images.append(key)
        return (" ".join(texts).strip() or None), images

    # Unwrap optional {"post": ...} envelope
    root = content_json
    if isinstance(root, dict) and isinstance(root.get("post"), dict):
        root = root["post"]
    if not isinstance(root, dict):
        return "", []

    # Direct format
    if "content" in root:
        text, imgs = _parse_block(root)
        if text or imgs:
            return text or "", imgs

    # Localized: prefer known locales, then fall back to any dict child
    for key in ("zh_cn", "en_us", "ja_jp"):
        if key in root:
            text, imgs = _parse_block(root[key])
            if text or imgs:
                return text or "", imgs
    for val in root.values():
        if isinstance(val, dict):
            text, imgs = _parse_block(val)
            if text or imgs:
                return text or "", imgs

    return "", []


def _extract_post_text(content_json: dict) -> str:
    """Extract plain text from Feishu post (rich text) message content.

    Legacy wrapper for _extract_post_content, returns only text.
    """
    text, _ = _extract_post_content(content_json)
    return text


class FeishuChannel(BaseChannel):
    """
    Feishu/Lark channel using WebSocket long connection.

    Uses WebSocket to receive events - no public IP or webhook required.

    Requires:
    - App ID and App Secret from Feishu Open Platform
    - Bot capability enabled
    - Event subscription enabled (im.message.receive_v1)
    """

    name = "feishu"

    def __init__(self, config: FeishuConfig, bus: MessageBus):
        super().__init__(config, bus)
        self.config: FeishuConfig = config
        self._client: Any = None
        self._ws_client: Any = None
        self._ws_thread: threading.Thread | None = None
        self._processed_message_ids: OrderedDict[str, None] = OrderedDict()  # Ordered dedup cache
        self._sender_cache: OrderedDict[str, _FeishuSenderInfo] = OrderedDict()
        self._loop: asyncio.AbstractEventLoop | None = None

    def _ensure_rest_client(self) -> bool:
        """Initialize the Feishu REST client without starting the WebSocket receiver."""
        if self._client is not None:
            return True
        if not FEISHU_AVAILABLE:
            logger.error("Feishu SDK not installed. Run: pip install lark-oapi")
            return False
        if not self.config.app_id or not self.config.app_secret:
            logger.error("Feishu app_id and app_secret not configured")
            return False
        import lark_oapi as lark

        self._client = lark.Client.builder() \
            .app_id(self.config.app_id) \
            .app_secret(self.config.app_secret) \
            .domain(self.config.domain) \
            .log_level(lark.LogLevel.INFO) \
            .build()
        return True

    async def start(self) -> None:
        """Start the Feishu bot with WebSocket long connection."""
        if not FEISHU_AVAILABLE:
            logger.error("Feishu SDK not installed. Run: pip install lark-oapi")
            return

        if not self.config.app_id or not self.config.app_secret:
            logger.error("Feishu app_id and app_secret not configured")
            return

        import lark_oapi as lark
        self._running = True
        self._loop = asyncio.get_running_loop()

        if not self._ensure_rest_client():
            return

        # Create event handler (only register message receive, ignore other events)
        event_handler = lark.EventDispatcherHandler.builder(
            self.config.encrypt_key or "",
            self.config.verification_token or "",
        ).register_p2_im_message_receive_v1(
            self._on_message_sync
        ).build()

        # Create WebSocket client for long connection
        self._ws_client = lark.ws.Client(
            self.config.app_id,
            self.config.app_secret,
            event_handler=event_handler,
            domain=self.config.domain,
            log_level=lark.LogLevel.INFO
        )

        # Start WebSocket client in a separate thread with reconnect loop.
        # A dedicated event loop is created for this thread so that lark_oapi's
        # module-level `loop = asyncio.get_event_loop()` picks up an idle loop
        # instead of the already-running main asyncio loop, which would cause
        # "This event loop is already running" errors.
        def run_ws():
            import time
            import lark_oapi.ws.client as _lark_ws_client
            ws_loop = asyncio.new_event_loop()
            asyncio.set_event_loop(ws_loop)
            # Patch the module-level loop used by lark's ws Client.start()
            _lark_ws_client.loop = ws_loop
            try:
                while self._running:
                    try:
                        self._ws_client.start()
                    except Exception as e:
                        logger.warning("Feishu WebSocket error: %s", e)
                    if self._running:
                        time.sleep(5)
            finally:
                ws_loop.close()

        self._ws_thread = threading.Thread(target=run_ws, daemon=True)
        self._ws_thread.start()

        logger.info("Feishu bot started with WebSocket long connection")
        logger.info("No public IP required - using WebSocket to receive events")

        # Keep running until stopped
        while self._running:
            await asyncio.sleep(1)

    async def stop(self) -> None:
        """
        Stop the Feishu bot.

        Notice: lark.ws.Client does not expose stop method， simply exiting the program will close the client.

        Reference: https://github.com/larksuite/oapi-sdk-python/blob/v2_main/lark_oapi/ws/client.py#L86
        """
        self._running = False
        logger.info("Feishu bot stopped")

    def _add_reaction_sync(self, message_id: str, emoji_type: str) -> None:
        """Sync helper for adding reaction (runs in thread pool)."""
        from lark_oapi.api.im.v1 import CreateMessageReactionRequest, CreateMessageReactionRequestBody, Emoji
        try:
            request = CreateMessageReactionRequest.builder() \
                .message_id(message_id) \
                .request_body(
                    CreateMessageReactionRequestBody.builder()
                    .reaction_type(Emoji.builder().emoji_type(emoji_type).build())
                    .build()
                ).build()

            response = self._client.im.v1.message_reaction.create(request)

            if not response.success():
                logger.warning("Failed to add reaction: code=%s, msg=%s", response.code, response.msg)
            else:
                logger.debug("Added %s reaction to message %s", emoji_type, message_id)
        except Exception as e:
            logger.warning("Error adding reaction: %s", e)

    async def _add_reaction(self, message_id: str, emoji_type: str = "THUMBSUP") -> None:
        """
        Add a reaction emoji to a message (non-blocking).

        Common emoji types: THUMBSUP, OK, EYES, DONE, OnIt, HEART
        """
        if not self._client:
            return

        loop = asyncio.get_running_loop()
        await loop.run_in_executor(None, self._add_reaction_sync, message_id, emoji_type)

    # Regex to match markdown tables (header + separator + data rows)
    _TABLE_RE = re.compile(
        r"((?:^[ \t]*\|.+\|[ \t]*\n)(?:^[ \t]*\|[-:\s|]+\|[ \t]*\n)(?:^[ \t]*\|.+\|[ \t]*\n?)+)",
        re.MULTILINE,
    )

    _HEADING_RE = re.compile(r"^(#{1,6})\s+(.+)$", re.MULTILINE)

    _CODE_BLOCK_RE = re.compile(r"(```[\s\S]*?```)", re.MULTILINE)

    @staticmethod
    def _parse_md_table(table_text: str) -> dict | None:
        """Parse a markdown table into a Feishu table element."""
        lines = [_line.strip() for _line in table_text.strip().split("\n") if _line.strip()]
        if len(lines) < 3:
            return None
        def split(_line: str) -> list[str]:
            return [c.strip() for c in _line.strip("|").split("|")]
        headers = split(lines[0])
        rows = [split(_line) for _line in lines[2:]]
        columns = [{"tag": "column", "name": f"c{i}", "display_name": h, "width": "auto"}
                   for i, h in enumerate(headers)]
        return {
            "tag": "table",
            "page_size": len(rows) + 1,
            "columns": columns,
            "rows": [{f"c{i}": r[i] if i < len(r) else "" for i in range(len(headers))} for r in rows],
        }

    def _build_card_elements(self, content: str) -> list[dict]:
        """Split content into div/markdown + table elements for Feishu card."""
        elements, last_end = [], 0
        for m in self._TABLE_RE.finditer(content):
            before = content[last_end:m.start()]
            if before.strip():
                elements.extend(self._split_headings(before))
            elements.append(self._parse_md_table(m.group(1)) or {"tag": "markdown", "content": m.group(1)})
            last_end = m.end()
        remaining = content[last_end:]
        if remaining.strip():
            elements.extend(self._split_headings(remaining))
        return elements or [{"tag": "markdown", "content": content}]

    @staticmethod
    def _split_elements_by_table_limit(elements: list[dict], max_tables: int = 1) -> list[list[dict]]:
        """Split card elements into groups with at most *max_tables* table elements each.

        Feishu cards have a hard limit of one table per card (API error 11310).
        When the rendered content contains multiple markdown tables each table is
        placed in a separate card message so every table reaches the user.
        """
        if not elements:
            return [[]]
        groups: list[list[dict]] = []
        current: list[dict] = []
        table_count = 0
        for el in elements:
            if el.get("tag") == "table":
                if table_count >= max_tables:
                    if current:
                        groups.append(current)
                    current = []
                    table_count = 0
                current.append(el)
                table_count += 1
            else:
                current.append(el)
        if current:
            groups.append(current)
        return groups or [[]]

    def _split_headings(self, content: str) -> list[dict]:
        """Split content by headings, converting headings to div elements."""
        protected = content
        code_blocks = []
        for m in self._CODE_BLOCK_RE.finditer(content):
            code_blocks.append(m.group(1))
            protected = protected.replace(m.group(1), f"\x00CODE{len(code_blocks)-1}\x00", 1)

        elements = []
        last_end = 0
        for m in self._HEADING_RE.finditer(protected):
            before = protected[last_end:m.start()].strip()
            if before:
                elements.append({"tag": "markdown", "content": before})
            text = m.group(2).strip()
            elements.append({
                "tag": "div",
                "text": {
                    "tag": "lark_md",
                    "content": f"**{text}**",
                },
            })
            last_end = m.end()
        remaining = protected[last_end:].strip()
        if remaining:
            elements.append({"tag": "markdown", "content": remaining})

        for i, cb in enumerate(code_blocks):
            for el in elements:
                if el.get("tag") == "markdown":
                    el["content"] = el["content"].replace(f"\x00CODE{i}\x00", cb)

        return elements or [{"tag": "markdown", "content": content}]

    # ── Smart format detection ──────────────────────────────────────────
    # Patterns that indicate "complex" markdown needing card rendering
    _COMPLEX_MD_RE = re.compile(
        r"```"                        # fenced code block
        r"|^\|.+\|.*\n\s*\|[-:\s|]+\|"  # markdown table (header + separator)
        r"|^#{1,6}\s+"                # headings
        , re.MULTILINE,
    )

    # Simple markdown patterns (bold, italic, strikethrough)
    _SIMPLE_MD_RE = re.compile(
        r"\*\*.+?\*\*"               # **bold**
        r"|__.+?__"                   # __bold__
        r"|(?<!\*)\*(?!\*)(.+?)(?<!\*)\*(?!\*)"  # *italic* (single *)
        r"|~~.+?~~"                   # ~~strikethrough~~
        , re.DOTALL,
    )

    # Markdown link: [text](url)
    _MD_LINK_RE = re.compile(r"\[([^\]]+)\]\((https?://[^\)]+)\)")

    # Unordered list items
    _LIST_RE = re.compile(r"^[\s]*[-*+]\s+", re.MULTILINE)

    # Ordered list items
    _OLIST_RE = re.compile(r"^[\s]*\d+\.\s+", re.MULTILINE)

    # Max length for plain text format
    _TEXT_MAX_LEN = 200

    # Max length for post (rich text) format; beyond this, use card
    _POST_MAX_LEN = 2000

    @classmethod
    def _detect_msg_format(cls, content: str) -> str:
        """Determine the optimal Feishu message format for *content*.

        Returns one of:
        - ``"text"``        – plain text, short and no markdown
        - ``"post"``        – rich text (links only, moderate length)
        - ``"interactive"`` – card with full markdown rendering
        """
        stripped = content.strip()

        # Complex markdown (code blocks, tables, headings) → always card
        if cls._COMPLEX_MD_RE.search(stripped):
            return "interactive"

        # Long content → card (better readability with card layout)
        if len(stripped) > cls._POST_MAX_LEN:
            return "interactive"

        # Has bold/italic/strikethrough → card (post format can't render these)
        if cls._SIMPLE_MD_RE.search(stripped):
            return "interactive"

        # Has list items → card (post format can't render list bullets well)
        if cls._LIST_RE.search(stripped) or cls._OLIST_RE.search(stripped):
            return "interactive"

        # Has links → post format (supports <a> tags)
        if cls._MD_LINK_RE.search(stripped):
            return "post"

        # Short plain text → text format
        if len(stripped) <= cls._TEXT_MAX_LEN:
            return "text"

        # Medium plain text without any formatting → post format
        return "post"

    @classmethod
    def _markdown_to_post(cls, content: str) -> str:
        """Convert markdown content to Feishu post message JSON.

        Handles links ``[text](url)`` as ``a`` tags; everything else as ``text`` tags.
        Each line becomes a paragraph (row) in the post body.
        """
        lines = content.strip().split("\n")
        paragraphs: list[list[dict]] = []

        for line in lines:
            elements: list[dict] = []
            last_end = 0

            for m in cls._MD_LINK_RE.finditer(line):
                # Text before this link
                before = line[last_end:m.start()]
                if before:
                    elements.append({"tag": "text", "text": before})
                elements.append({
                    "tag": "a",
                    "text": m.group(1),
                    "href": m.group(2),
                })
                last_end = m.end()

            # Remaining text after last link
            remaining = line[last_end:]
            if remaining:
                elements.append({"tag": "text", "text": remaining})

            # Empty line → empty paragraph for spacing
            if not elements:
                elements.append({"tag": "text", "text": ""})

            paragraphs.append(elements)

        post_body = {
            "zh_cn": {
                "content": paragraphs,
            }
        }
        return json.dumps(post_body, ensure_ascii=False)

    _IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp", ".ico", ".tiff", ".tif"}
    _AUDIO_EXTS = {".opus"}
    _VIDEO_EXTS = {".mp4", ".mov", ".avi"}
    _FILE_TYPE_MAP = {
        ".opus": "opus", ".mp4": "mp4", ".pdf": "pdf", ".doc": "doc", ".docx": "doc",
        ".xls": "xls", ".xlsx": "xls", ".ppt": "ppt", ".pptx": "ppt",
    }

    def _upload_image_sync(self, file_path: str) -> str | None:
        """Upload an image to Feishu and return the image_key."""
        from lark_oapi.api.im.v1 import CreateImageRequest, CreateImageRequestBody
        try:
            with open(file_path, "rb") as f:
                request = CreateImageRequest.builder() \
                    .request_body(
                        CreateImageRequestBody.builder()
                        .image_type("message")
                        .image(f)
                        .build()
                    ).build()
                response = self._client.im.v1.image.create(request)
                if response.success():
                    image_key = response.data.image_key
                    logger.debug("Uploaded image %s: %s", os.path.basename(file_path), image_key)
                    return image_key
                else:
                    logger.error("Failed to upload image: code=%s, msg=%s", response.code, response.msg)
                    return None
        except Exception as e:
            logger.error("Error uploading image %s: %s", file_path, e)
            return None

    def _upload_file_sync(self, file_path: str) -> str | None:
        """Upload a file to Feishu and return the file_key."""
        from lark_oapi.api.im.v1 import CreateFileRequest, CreateFileRequestBody
        ext = os.path.splitext(file_path)[1].lower()
        file_type = self._FILE_TYPE_MAP.get(ext, "stream")
        file_name = os.path.basename(file_path)
        try:
            with open(file_path, "rb") as f:
                request = CreateFileRequest.builder() \
                    .request_body(
                        CreateFileRequestBody.builder()
                        .file_type(file_type)
                        .file_name(file_name)
                        .file(f)
                        .build()
                    ).build()
                response = self._client.im.v1.file.create(request)
                if response.success():
                    file_key = response.data.file_key
                    logger.debug("Uploaded file %s: %s", file_name, file_key)
                    return file_key
                else:
                    logger.error("Failed to upload file: code=%s, msg=%s", response.code, response.msg)
                    return None
        except Exception as e:
            logger.error("Error uploading file %s: %s", file_path, e)
            return None

    def _download_image_sync(self, message_id: str, image_key: str) -> tuple[bytes | None, str | None]:
        """Download an image from Feishu message by message_id and image_key."""
        from lark_oapi.api.im.v1 import GetMessageResourceRequest
        try:
            request = GetMessageResourceRequest.builder() \
                .message_id(message_id) \
                .file_key(image_key) \
                .type("image") \
                .build()
            response = self._client.im.v1.message_resource.get(request)
            if response.success():
                file_data = response.file
                # GetMessageResourceRequest returns BytesIO, need to read bytes
                if hasattr(file_data, 'read'):
                    file_data = file_data.read()
                return file_data, response.file_name
            else:
                logger.error("Failed to download image: code=%s, msg=%s", response.code, response.msg)
                return None, None
        except Exception as e:
            logger.error("Error downloading image %s: %s", image_key, e)
            return None, None

    def _download_file_sync(
        self, message_id: str, file_key: str, resource_type: str = "file"
    ) -> tuple[bytes | None, str | None]:
        """Download a file/audio/media from a Feishu message by message_id and file_key."""
        from lark_oapi.api.im.v1 import GetMessageResourceRequest

        # Feishu API only accepts 'image' or 'file' as type parameter
        # Convert 'audio' to 'file' for API compatibility
        if resource_type == "audio":
            resource_type = "file"

        try:
            request = (
                GetMessageResourceRequest.builder()
                .message_id(message_id)
                .file_key(file_key)
                .type(resource_type)
                .build()
            )
            response = self._client.im.v1.message_resource.get(request)
            if response.success():
                file_data = response.file
                if hasattr(file_data, "read"):
                    file_data = file_data.read()
                return file_data, response.file_name
            else:
                logger.error("Failed to download %s: code=%s, msg=%s", resource_type, response.code, response.msg)
                return None, None
        except Exception:
            logger.exception("Error downloading %s %s", resource_type, file_key)
            return None, None

    async def _download_and_save_media(
        self,
        msg_type: str,
        content_json: dict,
        message_id: str | None = None
    ) -> tuple[str | None, str]:
        """
        Download media from Feishu and save to local disk.

        Returns:
            (file_path, content_text) - file_path is None if download failed
        """
        loop = asyncio.get_running_loop()
        media_dir = resolve_channel_media_dir(self.name)

        data, filename = None, None

        if msg_type == "image":
            image_key = content_json.get("image_key")
            if image_key and message_id:
                data, filename = await loop.run_in_executor(
                    None, self._download_image_sync, message_id, image_key
                )
                if not filename:
                    filename = f"{image_key[:16]}.jpg"

        elif msg_type in ("audio", "file", "media"):
            file_key = content_json.get("file_key")
            if file_key and message_id:
                data, filename = await loop.run_in_executor(
                    None, self._download_file_sync, message_id, file_key, msg_type
                )
                if not filename:
                    ext = {"audio": ".opus", "media": ".mp4"}.get(msg_type, "")
                    filename = f"{file_key[:16]}{ext}"

        if data and filename:
            safe_name = safe_filename(filename)
            if not safe_name:
                logger.warning("Rejected %s download with unsafe filename %r", msg_type, filename)
                return None, f"[{msg_type}: download failed]"

            media_root = media_dir.resolve()
            file_path = (media_root / safe_name).resolve()
            if not file_path.is_relative_to(media_root):
                logger.warning("Rejected %s download outside media directory: %r", msg_type, filename)
                return None, f"[{msg_type}: download failed]"

            file_path.write_bytes(data)
            logger.debug("Downloaded %s to %s", msg_type, file_path)
            return str(file_path), f"[{msg_type}: {safe_name}]"

        return None, f"[{msg_type}: download failed]"

    def _send_message_sync(self, receive_id_type: str, receive_id: str, msg_type: str, content: str, reply_in_thread: str | None = None) -> bool:
        """Send a single message (text/image/file/interactive) synchronously.

        When *reply_in_thread* (a message_id) is provided, the message is
        posted as a reply inside the originating thread via
        ``ReplyMessageRequest`` instead of a standalone message.
        """
        from lark_oapi.api.im.v1 import CreateMessageRequest, CreateMessageRequestBody
        try:
            if reply_in_thread:
                from lark_oapi.api.im.v1 import ReplyMessageRequest, ReplyMessageRequestBody
                request = ReplyMessageRequest.builder() \
                    .message_id(reply_in_thread) \
                    .request_body(
                        ReplyMessageRequestBody.builder()
                        .msg_type(msg_type)
                        .content(content)
                        .reply_in_thread(True)
                        .build()
                    ).build()
                response = self._client.im.v1.message.reply(request)
            else:
                request = CreateMessageRequest.builder() \
                    .receive_id_type(receive_id_type) \
                    .request_body(
                        CreateMessageRequestBody.builder()
                        .receive_id(receive_id)
                        .msg_type(msg_type)
                        .content(content)
                        .build()
                    ).build()
                response = self._client.im.v1.message.create(request)
            if not response.success():
                logger.error(
                    "Failed to send Feishu %s message: code=%s, msg=%s, log_id=%s",
                    msg_type, response.code, response.msg, response.get_log_id()
                )
                return False
            logger.debug("Feishu %s message sent to %s", msg_type, receive_id)
            return True
        except Exception as e:
            logger.error("Error sending Feishu %s message: %s", msg_type, e)
            return False

    @staticmethod
    def _format_response_error(action: str, response: Any) -> str:
        log_id = response.get_log_id() if hasattr(response, "get_log_id") else ""
        return (
            f"{action} failed: code={getattr(response, 'code', '')}, "
            f"msg={getattr(response, 'msg', '')}, log_id={log_id}"
        )

    def _create_managed_group_sync(self, user_open_id: str, name: str) -> str:
        """Create a Feishu group containing the user and the app bot."""
        from lark_oapi.api.im.v1 import CreateChatRequest, CreateChatRequestBody

        if not self._client:
            raise RuntimeError("Feishu client not initialized")
        request = (
            CreateChatRequest.builder()
            .user_id_type("open_id")
            .set_bot_manager(True)
            .request_body(
                CreateChatRequestBody.builder()
                .name(name)
                .user_id_list([user_open_id])
                .chat_mode("group")
                .chat_type("private")
                .build()
            )
            .build()
        )
        response = self._client.im.v1.chat.create(request)
        if not response.success():
            raise FeishuApiError(self._format_response_error("create Feishu group", response))
        chat_id = getattr(getattr(response, "data", None), "chat_id", None)
        if not chat_id:
            raise FeishuApiError("create Feishu group failed: response missing chat_id")
        logger.info("Created Feishu managed group name=%r chat_id=%s", name, chat_id)
        return str(chat_id)

    async def create_managed_group(self, *, user_open_id: str, name: str) -> str:
        """Create a Feishu group for a single user and the ohmo bot."""
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, self._create_managed_group_sync, user_open_id, name)

    def _rename_group_sync(self, chat_id: str, name: str) -> None:
        """Rename a Feishu group."""
        from lark_oapi.api.im.v1 import UpdateChatRequest, UpdateChatRequestBody

        if not self._client:
            raise RuntimeError("Feishu client not initialized")
        request = (
            UpdateChatRequest.builder()
            .user_id_type("open_id")
            .chat_id(chat_id)
            .request_body(UpdateChatRequestBody.builder().name(name).build())
            .build()
        )
        response = self._client.im.v1.chat.update(request)
        if not response.success():
            raise FeishuApiError(self._format_response_error("rename Feishu group", response))
        logger.info("Renamed Feishu group chat_id=%s name=%r", chat_id, name)

    async def rename_group(self, *, chat_id: str, name: str) -> None:
        """Rename a Feishu group."""
        loop = asyncio.get_running_loop()
        await loop.run_in_executor(None, self._rename_group_sync, chat_id, name)

    async def send(self, msg: OutboundMessage) -> None:
        """Send a message through Feishu, including media (images/files) if present."""
        if not self._ensure_rest_client():
            logger.warning("Feishu client not initialized")
            return

        try:
            receive_id_type = "chat_id" if msg.chat_id.startswith("oc_") else "open_id"
            loop = asyncio.get_running_loop()
            chat_type = str(msg.metadata.get("chat_type") or "").lower()
            reply_mid = (
                msg.metadata.get("message_id")
                if chat_type == "group" or msg.metadata.get("thread_id") or msg.metadata.get("root_id")
                else None
            )

            failed_media: list[str] = []
            sent_media: list[str] = []
            for file_path in msg.media:
                if not os.path.isfile(file_path):
                    logger.warning("Media file not found: %s", file_path)
                    failed_media.append(file_path)
                    continue
                ext = os.path.splitext(file_path)[1].lower()
                if ext in self._IMAGE_EXTS:
                    key = await loop.run_in_executor(None, self._upload_image_sync, file_path)
                    if key:
                        ok = await loop.run_in_executor(
                            None, self._send_message_sync,
                            receive_id_type, msg.chat_id, "image", json.dumps({"image_key": key}, ensure_ascii=False),
                            reply_mid,
                        )
                        if ok:
                            sent_media.append(file_path)
                        else:
                            failed_media.append(file_path)
                    else:
                        failed_media.append(file_path)
                else:
                    key = await loop.run_in_executor(None, self._upload_file_sync, file_path)
                    if key:
                        # Use msg_type "media" for audio/video so users can play inline;
                        # "file" for everything else (documents, archives, etc.)
                        if ext in self._AUDIO_EXTS or ext in self._VIDEO_EXTS:
                            media_type = "media"
                        else:
                            media_type = "file"
                        ok = await loop.run_in_executor(
                            None, self._send_message_sync,
                            receive_id_type, msg.chat_id, media_type, json.dumps({"file_key": key}, ensure_ascii=False),
                            reply_mid,
                        )
                        if ok:
                            sent_media.append(file_path)
                        else:
                            failed_media.append(file_path)
                    else:
                        failed_media.append(file_path)

            if failed_media:
                names = ", ".join(os.path.basename(path) for path in failed_media)
                failure_body = json.dumps({"text": f"文件发送失败：{names}"}, ensure_ascii=False)
                await loop.run_in_executor(
                    None, self._send_message_sync,
                    receive_id_type, msg.chat_id, "text", failure_body,
                    reply_mid,
                )

            if msg.content and msg.content.strip():
                fmt = self._detect_msg_format(msg.content)

                if fmt == "text":
                    # Short plain text – send as simple text message
                    text_body = json.dumps({"text": msg.content.strip()}, ensure_ascii=False)
                    await loop.run_in_executor(
                        None, self._send_message_sync,
                        receive_id_type, msg.chat_id, "text", text_body,
                        reply_mid,
                    )

                elif fmt == "post":
                    # Medium content with links – send as rich-text post
                    post_body = self._markdown_to_post(msg.content)
                    await loop.run_in_executor(
                        None, self._send_message_sync,
                        receive_id_type, msg.chat_id, "post", post_body,
                        reply_mid,
                    )

                else:
                    # Complex / long content – send as interactive card
                    elements = self._build_card_elements(msg.content)
                    for chunk in self._split_elements_by_table_limit(elements):
                        card = {"config": {"wide_screen_mode": True}, "elements": chunk}
                        await loop.run_in_executor(
                            None, self._send_message_sync,
                            receive_id_type, msg.chat_id, "interactive", json.dumps(card, ensure_ascii=False),
                            reply_mid,
                        )

        except Exception as e:
            logger.error("Error sending Feishu message: %s", e)

    def _resolve_sender_display_name_sync(self, open_id: str) -> str:
        """Resolve a human-friendly sender name from Feishu contact APIs."""
        cached = self._sender_cache.get(open_id)
        if cached is not None:
            self._sender_cache.move_to_end(open_id)
            return cached.display_name
        if not self._client or not open_id:
            return open_id or "unknown"

        try:
            import lark_oapi as lark

            request = (
                lark.api.contact.v3.GetUserRequest.builder()
                .user_id(open_id)
                .user_id_type("open_id")
                .build()
            )
            response = self._client.contact.v3.user.get(request)
            if getattr(response, "success", lambda: False)():
                user = getattr(getattr(response, "data", None), "user", None)
                display_name = (
                    getattr(user, "name", None)
                    or getattr(user, "en_name", None)
                    or getattr(user, "nickname", None)
                    or open_id
                )
            else:
                display_name = open_id
        except Exception:
            logger.exception("Failed to resolve Feishu sender name open_id=%s", open_id)
            display_name = open_id

        self._sender_cache[open_id] = _FeishuSenderInfo(open_id=open_id, display_name=display_name)
        while len(self._sender_cache) > 512:
            self._sender_cache.popitem(last=False)
        return display_name

    def _on_message_sync(self, data: "P2ImMessageReceiveV1") -> None:  # noqa: F821
        """
        Sync handler for incoming messages (called from WebSocket thread).
        Schedules async handling in the main event loop.
        """
        if self._loop and self._loop.is_running():
            asyncio.run_coroutine_threadsafe(self._on_message(data), self._loop)

    async def _on_message(self, data: "P2ImMessageReceiveV1") -> None:  # noqa: F821
        """Handle incoming message from Feishu."""
        try:
            event = data.event
            message = event.message
            sender = event.sender

            # Deduplication check
            message_id = message.message_id
            if message_id in self._processed_message_ids:
                return
            self._processed_message_ids[message_id] = None

            # Trim cache
            while len(self._processed_message_ids) > 1000:
                self._processed_message_ids.popitem(last=False)

            # Skip bot messages
            if sender.sender_type == "bot":
                return

            sender_id = sender.sender_id.open_id if sender.sender_id else "unknown"
            loop = asyncio.get_running_loop()
            sender_display_name = await loop.run_in_executor(
                None,
                self._resolve_sender_display_name_sync,
                sender_id,
            )
            chat_id = message.chat_id
            chat_type = message.chat_type
            msg_type = message.message_type

            # Parse content
            content_parts = []
            media_paths = []

            try:
                content_json = json.loads(message.content) if message.content else {}
            except json.JSONDecodeError:
                content_json = {}

            if msg_type == "text":
                text = content_json.get("text", "")
                if text:
                    content_parts.append(text)

            elif msg_type == "post":
                text, image_keys = _extract_post_content(content_json)
                if text:
                    content_parts.append(text)
                # Download images embedded in post
                for img_key in image_keys:
                    file_path, content_text = await self._download_and_save_media(
                        "image", {"image_key": img_key}, message_id
                    )
                    if file_path:
                        media_paths.append(file_path)
                    content_parts.append(content_text)

            elif msg_type in ("image", "audio", "file", "media"):
                file_path, content_text = await self._download_and_save_media(msg_type, content_json, message_id)
                if file_path:
                    media_paths.append(file_path)
                content_parts.append(content_text)

            elif msg_type in ("share_chat", "share_user", "interactive", "share_calendar_event", "system", "merge_forward"):
                # Handle share cards and interactive messages
                text = _extract_share_card_content(content_json, msg_type)
                if text:
                    content_parts.append(text)

            else:
                content_parts.append(MSG_TYPE_MAP.get(msg_type, f"[{msg_type}]"))

            content = "\n".join(content_parts) if content_parts else ""

            if not content and not media_paths:
                return
            mentions = _extract_feishu_mentions(content_json, getattr(message, "mentions", None))
            mentions_bot = chat_type == "group" and _feishu_mentions_bot(
                content_json,
                content,
                self.config,
                mentions=mentions,
            )
            if not _should_process_feishu_group_message(
                chat_type=chat_type,
                chat_id=chat_id,
                mentions_bot=mentions_bot,
                config=self.config,
            ):
                logger.info(
                    "Feishu group message ignored by policy chat_id=%s policy=%s mentions_bot=%s mention_names=%s mention_open_ids=%s",
                    chat_id,
                    getattr(self.config, "group_policy", "managed_or_mention"),
                    mentions_bot,
                    [item.get("name", "") for item in mentions],
                    [item.get("open_id", "") for item in mentions],
                )
                return

            # Add reaction only after policy says this message will be handled.
            await self._add_reaction(message_id, self.config.react_emoji)

            # Forward to message bus
            reply_to = chat_id if chat_type == "group" else sender_id

            # thread_id enables per-topic session routing in router.py
            thread_id = getattr(message, "thread_id", None) or getattr(message, "root_id", None)

            await self._handle_message(
                sender_id=sender_id,
                chat_id=reply_to,
                content=content,
                media=media_paths,
                metadata={
                    "message_id": message_id,
                    "thread_id": thread_id,
                    "root_id": getattr(message, "root_id", None),
                    "chat_type": chat_type,
                    "msg_type": msg_type,
                    "mentions": mentions,
                    "mentions_bot": mentions_bot,
                    "sender_display_name": sender_display_name,
                    "sender_label": sender_display_name or sender_id,
                }
            )

        except Exception as e:
            logger.error("Error processing Feishu message: %s", e)
